var navigation="<div class=\"navbar-default sidebar\" role=\"navigation\">";
navigation+="<div class=\"ht-logo\"><a href=\"#\"><img src=\"images/logo.png\" /></a></div>";
navigation+="<div class=\"sidebar-nav navbar-collapse\">";
navigation+="<ul class=\"nav\" id=\"side-menu\">";
//++++++++++++++++++++++����
navigation+="<li><a href=\"#\" class=\"nav-title\"><i class=\"fa fa-indent nav_icon\">|</i><script type=\"text/javascript\">document.write(str_system);</script><span class=\"fa arrow\"></span></a>";
navigation+="<ul class=\"nav nav-second-level\">";
navigation+="<li class=\"nav-list\"><a href=\"index.html\"><script type=\"text/javascript\">document.write(str_wlan_base_set);</script></a></li>";
navigation+="<li class=\"nav-list\"><a href=\"restart.html\"><script type=\"text/javascript\">document.write(str_reboot);</script></a></li>";
navigation+="</ul></li>";

navigation+="<li><a href=\"#\" class=\"nav-title\"><i class=\"fa fa-envelope nav_icon\">|</i><script type=\"text/javascript\">document.write(str_hls_live);</script><span class=\"fa arrow\"></span></a>";
navigation+="<ul class=\"nav nav-second-level\">";
navigation+="<li class=\"nav-list\"><a href=\"hlsconfig.html\"><script type=\"text/javascript\">document.write(str_hls_live_config);</script></a></li>";
navigation+="<li class=\"nav-list\"><a href=\"hlslist.html\"><script type=\"text/javascript\">document.write(str_hls_live_list);</script></a></li>";
navigation+="</ul></li>";

navigation+="<li><a href=\"#\" class=\"nav-title\"><i class=\"fa fa-envelope nav_icon\">|</i><script type=\"text/javascript\">document.write(str_rtsp_live);</script><span class=\"fa arrow\"></span></a>";
navigation+="<ul class=\"nav nav-second-level\">";
navigation+="<li class=\"nav-list\"><a href=\"rtspconfig.html\"><script type=\"text/javascript\">document.write(str_rtsp_live_config);</script></a></li>";
navigation+="<li class=\"nav-list\"><a href=\"rtsplist.html\"><script type=\"text/javascript\">document.write(str_rtsp_live_list);</script></a></li>";
navigation+="</ul></li>";





//++++++++++++++++++++++
navigation+="</ul></div></div>";

var contextright=" <div class=\"m-top\">";
contextright+="<span id=\"dvruntime\" class=\"m-time\"></span>";
contextright+="<div class=\"m-record\"><span class=\"rec-3\"><a href=\"/login.html\"><script type=\"text/javascript\">document.write(str_quit);</script></a></span> </div>";
contextright+="<div class=\"clear\"></div></div>";					


