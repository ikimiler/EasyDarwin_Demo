var siteList={ "EasyDarwin" :
 { "Body" : 
 { "SessionCount" : "13",
 "Sessions" : [
 { "Bitrate" : 29766, "index" : 0, "name" : "c42f90d7482b", "source" : "rtsp://127.0.0.1:554/c42f90d7482b.sdp", "url" : "http://218.75.172.131:1001/c42f90d7482b/c42f90d7482b.m3u8" }, 
 { "Bitrate" : 90083, "index" : 1, "name" : "00121280f288", "source" : "rtsp://127.0.0.1:554/00121280f288.sdp", "url" : "http://218.75.172.131:1001/00121280f288/00121280f288.m3u8" },
 { "Bitrate" : 71846, "index" : 2, "name" : "001212825109", "source" : "rtsp://127.0.0.1:554/001212825109.sdp", "url" : "http://218.75.172.131:1001/001212825109/001212825109.m3u8" }, 
 { "Bitrate" : 88211, "index" : 3, "name" : "00121279fc72", "source" : "rtsp://127.0.0.1:554/00121279fc72.sdp", "url" : "http://218.75.172.131:1001/00121279fc72/00121279fc72.m3u8" }, 
 { "Bitrate" : 9573, "index" : 4, "name" : "0012125215ad", "source" : "rtsp://127.0.0.1:554/0012125215ad.sdp", "url" : "http://218.75.172.131:1001/0012125215ad/0012125215ad.m3u8" }, 
 { "Bitrate" : 85183, "index" : 5, "name" : "0012127f037d", "source" : "rtsp://127.0.0.1:554/0012127f037d.sdp", "url" : "http://218.75.172.131:1001/0012127f037d/0012127f037d.m3u8" },
 { "Bitrate" : 101180, "index" : 6, "name" : "001212812f40", "source" : "rtsp://127.0.0.1:554/001212812f40.sdp", "url" : "http://218.75.172.131:1001/001212812f40/001212812f40.m3u8" },
 { "Bitrate" : 99228, "index" : 7, "name" : "00121281070f", "source" : "rtsp://127.0.0.1:554/00121281070f.sdp", "url" : "http://218.75.172.131:1001/00121281070f/00121281070f.m3u8" }, 
 { "Bitrate" : 91492, "index" : 8, "name" : "0012127f2fa8", "source" : "rtsp://127.0.0.1:554/0012127f2fa8.sdp", "url" : "http://218.75.172.131:1001/0012127f2fa8/0012127f2fa8.m3u8" },
 { "Bitrate" : 88563, "index" : 9, "name" : "001212b32ab5", "source" : "rtsp://127.0.0.1:554/001212b32ab5.sdp", "url" : "http://218.75.172.131:1001/001212b32ab5/001212b32ab5.m3u8" }, 
 { "Bitrate" : 87810, "index" : 10, "name" : "001212816eaf", "source" : "rtsp://127.0.0.1:554/001212816eaf.sdp", "url" : "http://218.75.172.131:1001/001212816eaf/001212816eaf.m3u8" },
 { "Bitrate" : 41559, "index" : 11, "name" : "c42f90c9d020", "source" : "rtsp://127.0.0.1:554/c42f90c9d020.sdp", "url" : "http://218.75.172.131:1001/c42f90c9d020/c42f90c9d020.m3u8" }, 
 { "Bitrate" : 118723, "index" : 12, "name" : "c42f901ba64a", "source" : "rtsp://127.0.0.1:554/c42f901ba64a.sdp", "url" : "http://218.75.172.131:1001/c42f901ba64a/c42f901ba64a.m3u8" } ] },
 "Header" : { "CSeq" : "1", "MessageType" : "MSG_CLI_SMS_HLS_LIST_ACK", "Version" : "1.0" } } } 